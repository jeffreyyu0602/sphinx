#!/usr/bin/env python3
"""Drive the POWER_LOOP firmware on the Sphinx chip for a steady-state power
measurement. These ELFs replay their layer forever (`while (1)` around the
program body, see EmitC.cc), so unlike the graded ones they never return and
`run_layers.py` cannot drive them.

    python run_power.py list
    python run_power.py start  --network llama_prefill --layer 5
    python run_power.py sample --seconds 60 --clock-mhz 100
    python run_power.py stop

Every command starts OpenOCD itself (--openocd-cfg, default openocd.cfg in
the current folder), waits for its gdb port, does its work over GDB and stops
OpenOCD again. Nothing has to run in another terminal, and a reset between
layers leaves nothing stale behind. The chip keeps running when OpenOCD
exits, so after `start` the loop spins with no debugger attached at all.

`list` numbers the layers of each network; --layer takes that number or the
full name. `start` resets the SoC, loads the layer's ELF, sets the entry PC,
resumes, detaches and prints which layer is running; --verify-seconds N then
samples the counters for N seconds to confirm the loop is live.
`sample` reads the accelerator cycle counters twice, --seconds apart, and
reports what share of the wall clock each unit was busy. It divides by the
interval the two reads actually spanned, not by --seconds: each read costs a
few seconds of GDB startup that falls inside the window, so a short window
otherwise reads far too high. `stop` halts the chip.
"""
import argparse
import os
import re
import subprocess
import sys
import time

CONFIG = os.path.join("MXNF4", "64x64_512x576x256_true_true_true")
ENTRY = 0x40000000

COUNTERS = [
    ("matrix", 0x20000108),
    ("vector", 0x20000208),
    ("mvm", 0x20000308),
    ("spmm", 0x20000408),
    ("accelerator", 0x20000008),
]

GDB_PREAMBLE = [
    "set confirm off",
    "set pagination off",
    "set arch riscv:rv64",
    "set remotetimeout 3600",
]

# No breakpoint: the firmware never reaches an exit. Detaching leaves the core
# running, so GDB and OpenOCD add nothing to what the meter sees.
START_COMMANDS = [
    "monitor reset halt",
    "load",
    f"set $pc = {ENTRY:#x}",
    "monitor resume",
    "detach",
]


class OpenOCD:
    """One OpenOCD process logging to a file, usable once it announces its gdb
    port -- the same wait run_voyager.py does for its simulated JTAG."""

    def __init__(self, args, log_path):
        self.log_path = log_path
        os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)
        self.log = open(log_path, "w")
        self.proc = subprocess.Popen(["openocd", "-f", args.openocd_cfg],
                                     stdout=self.log, stderr=subprocess.STDOUT)
        try:
            self.port = self.wait_for(r"Listening on port (\d+) for gdb connections",
                                      args.openocd_timeout).group(1)
        except Exception:
            self.stop()
            raise

    def wait_for(self, pattern, timeout):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with open(self.log_path) as f:
                for line in f:
                    m = re.search(pattern, line)
                    if m:
                        return m
            if self.proc.poll() is not None:
                raise RuntimeError(f"openocd exited with {self.proc.returncode}, "
                                   f"see {self.log_path}")
            time.sleep(0.5)
        raise TimeoutError(f"openocd did not announce a gdb port within {timeout} s, "
                           f"see {self.log_path}")

    def stop(self):
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait()
        self.log.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.stop()


def gdb(args, port, commands, elf=None, log_path=None):
    """Run one batch GDB session over the commands; return (output, exit code).

    GDB stops at the first failing command and exits non-zero, so a failed
    load shows as a non-zero code rather than a partially run script.
    """
    script = "\n".join(GDB_PREAMBLE + [f"target extended-remote localhost:{port}"]
                       + commands + ["quit"]) + "\n"
    path = os.path.join(args.out, "power.gdb")
    os.makedirs(args.out, exist_ok=True)
    with open(path, "w") as f:
        f.write(script)
    cmd = [args.gdb, "--batch"] + ([elf] if elf else []) + ["-x", path]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          text=True, timeout=args.timeout)
    if log_path:
        with open(log_path, "w") as f:
            f.write(proc.stdout)
    return proc.stdout, proc.returncode


def layer_dir(args, network):
    return os.path.join(args.dir, network, CONFIG)


def layers_of(args, network):
    """The network's layer ELFs in the order the network runs them, which is
    the order `list` numbers them.

    The kit ships the compiler's layers.txt beside the ELFs (first column: the
    layer, one line per layer in program order); an ELF it does not name, or a
    kit without it, falls back to name order.
    """
    d = layer_dir(args, network)
    if not os.path.isdir(d):
        sys.exit(f"no network {network} under {args.dir}; see `run_power.py list`")
    elfs = sorted(f[:-6] for f in os.listdir(d) if f.endswith(".riscv"))
    program_order = {}
    try:
        with open(os.path.join(d, "layers.txt")) as f:
            for line in f:
                fields = line.split()
                if fields and fields[0] not in program_order:
                    program_order[fields[0]] = len(program_order)
    except FileNotFoundError:
        return elfs
    return sorted(elfs, key=lambda layer: (program_order.get(layer, len(program_order)), layer))


def resolve_layer(args, layers):
    """--layer as the number `list` shows, or as the full name; returns both."""
    if args.layer is None:
        sys.exit("start needs --layer <number|name>; see `run_power.py list`")
    if args.layer.isdigit():
        index = int(args.layer)
        if not 1 <= index <= len(layers):
            sys.exit(f"--layer {index}: {args.network} has layers 1..{len(layers)}")
        return index, layers[index - 1]
    if args.layer not in layers:
        sys.exit(f"no layer {args.layer} in {args.network}; see `run_power.py list`")
    return layers.index(args.layer) + 1, args.layer


def cmd_list(args):
    for network in sorted(n for n in os.listdir(args.dir)
                          if os.path.isdir(layer_dir(args, n))):
        layers = layers_of(args, network)
        print(f"{network} ({len(layers)} layers):")
        for i, layer in enumerate(layers, 1):
            print(f"  [{i:2d}] {layer}")


def cmd_start(args):
    layers = layers_of(args, args.network)
    index, layer = resolve_layer(args, layers)
    elf = os.path.join(layer_dir(args, args.network), layer + ".riscv")
    out = os.path.join(args.out, args.network)
    os.makedirs(out, exist_ok=True)
    print(f"[{index}/{len(layers)}] {args.network}/{layer}: starting OpenOCD, loading")
    with OpenOCD(args, os.path.join(out, f"{layer}_openocd.log")) as ocd:
        text, code = gdb(args, ocd.port, START_COMMANDS, elf=elf,
                         log_path=os.path.join(out, f"{layer}_gdb.log"))
        if code != 0:
            print(text.strip()[-2000:])
            sys.exit(f"GDB exited with {code}: {layer} did not start "
                     f"(see {out}/{layer}_gdb.log and {layer}_openocd.log)")
        if args.verify_seconds > 0:
            elapsed, deltas = sample(args, ocd.port, args.verify_seconds)
            report_sample(args, elapsed, deltas, args.verify_seconds)
    print(f"[{index}/{len(layers)}] {args.network}/{layer} is running; "
          f"OpenOCD stopped. Measure now.")
    if index < len(layers):
        print(f"next: --layer {index + 1}  ({layers[index]})")


def read_counters(args, port):
    """Read the counters once, and return them with the time they were taken.

    The values are captured at the `monitor halt` inside the GDB session, which
    is neither the start nor the end of the call, so the midpoint stands in for
    it. Both reads of a sample run the same commands, so whatever that estimate
    is off by is the same for each and cancels in the difference.
    """
    cmds = ["monitor halt"]
    for name, addr in COUNTERS:
        cmds.append(f'printf "COUNTER {name} %llu\\n", *(unsigned long long*){addr:#x}')
    cmds += ["monitor resume", "detach"]
    started = time.monotonic()
    out, _ = gdb(args, port, cmds)
    captured = (started + time.monotonic()) / 2
    found = {}
    for name, _ in COUNTERS:
        m = re.search(rf"^COUNTER {name} (\d+)", out, re.M)
        if m:
            found[name] = int(m.group(1))
    return found, captured


def sample(args, port, seconds):
    """Two counter reads `seconds` apart; return (elapsed, {name: delta})."""
    before, taken_before = read_counters(args, port)
    time.sleep(seconds)
    after, taken_after = read_counters(args, port)
    # Each read spawns a GDB process and connects over JTAG, seconds that fall
    # inside the window. Dividing by `seconds` rather than by the interval the
    # reads actually spanned is what made a 10 s sample read 43 % high.
    elapsed = taken_after - taken_before
    deltas = {name: after[name] - before[name]
              for name, _ in COUNTERS if name in before and name in after}
    return elapsed, deltas


def busy_percent(args, elapsed, cycles):
    return 100.0 * (cycles / elapsed / 1e6) / args.clock_mhz


def report_sample(args, elapsed, deltas, requested):
    print(f"over {elapsed:.1f} s measured ({requested:.1f} s requested), "
          f"chip clock {args.clock_mhz:g} MHz:")
    for name, _ in COUNTERS:
        if name in deltas:
            rate = deltas[name] / elapsed / 1e6
            print(f"  {name:12} {deltas[name]:14d} cycles  {rate:8.2f} Mcycles/s  "
                  f"{busy_percent(args, elapsed, deltas[name]):6.1f} % busy")
    acc = deltas.get("accelerator", 0)
    if acc == 0:
        print("\naccelerator cycle count did not move: the loop is not running")
        return
    # The counter advances at most once per clock, so a duty cycle above 100 %
    # can only mean --clock-mhz is below the rate the chip is really running at.
    duty = busy_percent(args, elapsed, acc)
    if duty > 105.0:
        print(f"\naccelerator busy {duty:.0f} % of wall time, which is impossible: "
              f"the chip clock is above the {args.clock_mhz:g} MHz given")


def cmd_sample(args):
    with OpenOCD(args, os.path.join(args.out, "openocd-sample.log")) as ocd:
        elapsed, deltas = sample(args, ocd.port, args.seconds)
    report_sample(args, elapsed, deltas, args.seconds)


def cmd_stop(args):
    with OpenOCD(args, os.path.join(args.out, "openocd-stop.log")) as ocd:
        gdb(args, ocd.port, ["monitor reset halt", "detach"])
    print("chip halted")


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", choices=["list", "start", "sample", "stop"])
    p.add_argument("--dir", default="networks", help="folder with one sub-folder per network")
    p.add_argument("--out", default="power", help="folder for logs and GDB scripts")
    p.add_argument("--network", default="llama_prefill")
    p.add_argument("--layer", default=None, help="start: the layer's number from `list`, or its name")
    p.add_argument("--seconds", type=float, default=60.0, help="sample: the window")
    p.add_argument("--clock-mhz", type=float, default=100.0,
                   help="chip clock, to report each counter as a duty cycle")
    p.add_argument("--verify-seconds", type=float, default=0.0,
                   help="start: sample the counters this long after the load (0 = skip)")
    p.add_argument("--openocd-cfg", default="openocd.cfg", help="OpenOCD config for the J-Link")
    p.add_argument("--openocd-timeout", type=float, default=60.0,
                   help="seconds to wait for OpenOCD's gdb port")
    p.add_argument("--gdb", default="riscv-none-embed-gdb", help="GDB executable")
    p.add_argument("--timeout", type=int, default=1800, help="seconds per GDB call")
    args = p.parse_args()

    if args.command != "list" and not os.path.exists(args.openocd_cfg):
        sys.exit(f"no OpenOCD config at {args.openocd_cfg} (--openocd-cfg)")
    {"list": cmd_list, "start": cmd_start,
     "sample": cmd_sample, "stop": cmd_stop}[args.command](args)


if __name__ == "__main__":
    main()
