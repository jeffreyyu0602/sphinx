#!/usr/bin/env python3
"""Run every layer ELF of every network in a folder on the Sphinx chip over
JTAG and read the results back.

    python run_layers.py --dir networks --out results
    python run_layers.py --dir networks --networks llama_decode,llama_decode_kivi
    python run_layers.py --dir networks --networks llama_prefill --layers neg,mul_5

--dir is the folder that holds one sub-folder per network, as in the zip:
    networks/<network>/MXNF4/64x64_512x576x256_true_true_true/<layer>.riscv
                                                            /<layer>_scratchpad_dump.txt
Every network found there runs unless --networks names some. For each layer a
GDB command file is written that resets the SoC, loads the ELF, runs to
_exit, prints the accelerator cycle counters and dumps each read-back region
(from the layer's dump list) to
    <out>/<network>/<network>_<layer>_scratchpad.bin.<i>
Each region is then compared here, byte for byte, against the reference
emitted beside the ELF (<layer>_scratchpad_expected.bin.<i>, written by
`jtag_sim_checker --emit-reference`), so nothing has to be copied to the
server. A layer with no reference still runs and dumps, and keeps its own
status. Also per network: <layer>.gdb, <layer>.log and summary.csv; and
<out>/summary.csv over all networks.

OpenOCD must already be running (gdb port 3333 by default).
"""
import argparse
import csv
import os
import re
import subprocess
import sys
import time

CONFIG = os.path.join("MXNF4", "64x64_512x576x256_true_true_true")

COUNTERS = [
    ("matrix", 0x20000108),
    ("vector", 0x20000208),
    ("mvm", 0x20000308),
    ("spmm", 0x20000408),
    ("accelerator", 0x20000008),
]

FIELDS = (["network", "layer", "status", "gdb_exit", "seconds", "regions", "errors",
           "graded", "zeros"] + [n for n, _ in COUNTERS])


def signed_zero(got, want, i):
    """True when byte i differs only as the sign of a bf16 zero.

    bf16 is two bytes little-endian, so the sign is the odd byte and the value
    is zero when the even byte is zero in both. -0.0 and +0.0 compare equal,
    which is the verdict jtag_sim_checker gives (it compares decoded values),
    so such a byte is not an error. `neg` negates, so it is the layer that
    turns a zero into -0.0 where the chip leaves +0.0.
    """
    return (i % 2 == 1 and {got[i], want[i]} == {0x00, 0x80}
            and got[i - 1] == 0 and want[i - 1] == 0)


def compare_region(dump_path, expected_path):
    """(errors, compared bytes, first bad offset, signed zeros) for one region.

    Every byte of a dumped region is graded -- the dump list is the emitter's
    readback_regions(), the scratchpad-resident outputs bounded to the bytes
    gold wrote -- and gold and the accelerator are compared with no tolerance,
    so a byte compare is the verdict jtag_sim_checker gives, except for the
    signed zeros above, which are counted apart rather than hidden.
    """
    with open(dump_path, "rb") as f:
        got = f.read()
    with open(expected_path, "rb") as f:
        want = f.read()
    n = min(len(got), len(want))
    if got[:n] == want[:n] and len(got) == len(want):
        return 0, n, None, 0

    errors, first, zeros = 0, None, 0
    for i in range(n):
        if got[i] == want[i]:
            continue
        if signed_zero(got, want, i):
            zeros += 1
            continue
        errors += 1
        if first is None:
            first = i
    errors += abs(len(got) - len(want))
    return errors, n, first, zeros


def check_layer(layer_dir, layer, prefix, regions):
    """(status, errors, graded bytes, detail lines) from the saved reference.

    status is None when there is no reference to grade against, leaving the
    caller's own status alone.
    """
    ref = os.path.join(layer_dir, layer + "_scratchpad")
    if not os.path.exists(f"{ref}_expected.bin.0"):
        return None, "", "", "", []
    errors, graded, zeros, detail = 0, 0, 0, []
    for i in range(len(regions)):
        expected = f"{ref}_expected.bin.{i}"
        if not os.path.exists(expected):
            return "NO REFERENCE", "", "", "", [f"region {i}: {expected} is missing"]
        bad, compared, first, zero = compare_region(f"{prefix}.{i}", expected)
        errors += bad
        graded += compared
        zeros += zero
        if bad:
            detail.append(f"region {i}: {bad} of {compared} bytes differ, "
                          f"first at region offset {first:#x}")
        if zero:
            detail.append(f"region {i}: {zero} signed-zero byte(s), not an error "
                          f"(-0.0 equals +0.0)")
    return ("ok" if errors == 0 else "MISMATCH"), errors, graded, zeros, detail


def gdb_script(dump_list, prefix, port):
    lines = [
        "set confirm off",
        "set pagination off",
        "set arch riscv:rv64",
        "set remotetimeout 3600",
        f"target extended-remote localhost:{port}",
        "monitor reset halt",
    ]
    # The cycle counters are read-only and clear only on a real SoC reset,
    # which the debug module's reset may not deliver on the board. Sample
    # them before the run and report the difference, so each layer's numbers
    # stand alone whatever the reset did.
    for name, addr in COUNTERS:
        lines.append(f'printf "BASE {name} %llu\\n", *(unsigned long long*){addr:#x}')
    lines += [
        "load",
        "set $pc = 0x40000000",
        "break _exit",
        "continue",
    ]
    for name, addr in COUNTERS:
        lines.append(f'printf "COUNTER {name} %llu\\n", *(unsigned long long*){addr:#x}')
    with open(dump_list) as f:
        regions = [line.split() for line in f if line.strip()]
    for i, (start, length) in enumerate(regions):
        begin = int(start, 0)
        end = begin + int(length, 0)
        lines.append(f"dump binary memory {prefix}.{i} {begin:#x} {end:#x}")
        lines.append(f'printf "DUMPED {i} {begin:#x} {end:#x}\\n"')
    lines.append("quit")
    return "\n".join(lines) + "\n", regions


def run_layer(args, network, layer_dir, out_dir, layer):
    elf = os.path.join(layer_dir, layer + ".riscv")
    dump_list = os.path.join(layer_dir, layer + "_scratchpad_dump.txt")
    row = {"network": network, "layer": layer}
    if not os.path.exists(dump_list):
        # An ELF without a dump list was not emitted for full JTAG mode (a
        # stale program-mode build, or a layer full mode refused): nothing
        # to read back, so it is not run.
        row["status"] = "skipped"
        row["regions"] = "no dump list"
        with open(os.path.join(out_dir, layer + ".log"), "w") as f:
            f.write(f"skipped: {dump_list} does not exist; {elf} is not a full-mode ELF\n")
        return row
    prefix = os.path.join(out_dir, f"{network}_{layer}_scratchpad.bin")
    script, regions = gdb_script(dump_list, prefix, args.port)
    script_path = os.path.join(out_dir, layer + ".gdb")
    with open(script_path, "w") as f:
        f.write(script)

    t0 = time.time()
    try:
        proc = subprocess.run(
            [args.gdb, "--batch", elf, "-x", script_path],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            timeout=args.timeout,
        )
    except subprocess.TimeoutExpired:
        row["status"] = "TIMEOUT"
        return row
    row["seconds"] = f"{time.time() - t0:.1f}"
    with open(os.path.join(out_dir, layer + ".log"), "w") as f:
        f.write(proc.stdout)

    row["gdb_exit"] = proc.returncode
    for name, _ in COUNTERS:
        after = re.search(rf"^COUNTER {name} (\d+)", proc.stdout, re.M)
        before = re.search(rf"^BASE {name} (\d+)", proc.stdout, re.M)
        if after and before:
            row[name] = str(int(after.group(1)) - int(before.group(1)))
        else:
            row[name] = after.group(1) if after else ""
    dumped = len(re.findall(r"^DUMPED ", proc.stdout, re.M))
    row["regions"] = f"{dumped}/{len(regions)}"
    ok = (proc.returncode == 0 and dumped == len(regions)
          and all(os.path.exists(f"{prefix}.{i}")
                  and os.path.getsize(f"{prefix}.{i}") == int(r[1], 0)
                  for i, r in enumerate(regions)))
    row["status"] = "ok" if ok else "FAILED"
    if not ok:
        return row

    graded_status, row["errors"], row["graded"], row["zeros"], detail = check_layer(
        layer_dir, layer, prefix, regions)
    if graded_status is not None:
        row["status"] = graded_status
    if detail:
        with open(os.path.join(out_dir, layer + ".log"), "a") as f:
            f.write("\n" + "\n".join(detail) + "\n")
    return row


def layers_in_program_order(layer_dir):
    """The layer ELFs in the order the network runs them: the kit ships the
    compiler's layers.txt beside them (first column: the layer, one line per
    layer in program order). An ELF it does not name, or a kit without it,
    falls back to name order."""
    elfs = sorted(f[:-6] for f in os.listdir(layer_dir) if f.endswith(".riscv"))
    program_order = {}
    try:
        with open(os.path.join(layer_dir, "layers.txt")) as f:
            for line in f:
                fields = line.split()
                if fields and fields[0] not in program_order:
                    program_order[fields[0]] = len(program_order)
    except FileNotFoundError:
        return elfs
    return sorted(elfs, key=lambda layer: (program_order.get(layer, len(program_order)), layer))


def write_summary(path, rows):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in FIELDS})


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dir", default="networks", help="folder with one sub-folder per network")
    p.add_argument("--out", default="results", help="output folder; gets one sub-folder per network")
    p.add_argument("--networks", default=None, help="comma list; default: every network under --dir")
    p.add_argument("--layers", default=None, help="comma list; default: every .riscv of each network")
    p.add_argument("--gdb", default="riscv-none-embed-gdb", help="GDB executable")
    p.add_argument("--port", default="3333", help="OpenOCD gdb port")
    p.add_argument("--timeout", type=int, default=1800, help="seconds per layer")
    args = p.parse_args()

    if args.networks:
        networks = args.networks.split(",")
    else:
        networks = sorted(n for n in os.listdir(args.dir)
                          if os.path.isdir(os.path.join(args.dir, n, CONFIG)))
    if not networks:
        sys.exit(f"no <network>/{CONFIG} folders under {args.dir}")

    all_rows = []
    for network in networks:
        layer_dir = os.path.join(args.dir, network, CONFIG)
        if not os.path.isdir(layer_dir):
            print(f"== {network}: no {layer_dir}, skipped", flush=True)
            all_rows.append({"network": network, "layer": "", "status": "no folder"})
            continue
        if args.layers:
            layers = args.layers.split(",")
        else:
            layers = layers_in_program_order(layer_dir)
        out_dir = os.path.join(args.out, network)
        os.makedirs(out_dir, exist_ok=True)
        print(f"== {network}: {len(layers)} layer(s) -> {out_dir}", flush=True)
        rows = []
        for layer in layers:
            row = run_layer(args, network, layer_dir, out_dir, layer)
            rows.append(row)
            print("   " + f"{layer:44s} " +
                  "  ".join(f"{k}={row.get(k, '')}" for k in FIELDS[2:]), flush=True)
        write_summary(os.path.join(out_dir, "summary.csv"), rows)
        ok = sum(r.get("status") == "ok" for r in rows)
        skipped = sum(r.get("status") == "skipped" for r in rows)
        print(f"   {ok}/{len(rows) - skipped} passed"
              + (f", {skipped} skipped (no dump list)" if skipped else ""), flush=True)
        all_rows += rows

    write_summary(os.path.join(args.out, "summary.csv"), all_rows)
    skipped = [f"{r['network']}/{r['layer']}" for r in all_rows if r.get("status") == "skipped"]
    bad = [f"{r['network']}/{r['layer']}" for r in all_rows
           if r.get("status") not in ("ok", "skipped")]
    ran = len(all_rows) - len(skipped)
    ungraded = [f"{r['network']}/{r['layer']}" for r in all_rows if r.get("graded") == ""]
    print(f"\n{ran - len(bad)}/{ran} layers passed; "
          f"summary in {os.path.join(args.out, 'summary.csv')}")
    if skipped:
        print("skipped (no dump list, not full-mode ELFs): " + ", ".join(skipped))
    if bad:
        print("FAILED: " + ", ".join(bad))
    if ungraded:
        print("ran but not graded (no reference emitted): " + ", ".join(ungraded))
    print(f"Copy {args.out}/ to the server only to re-grade a MISMATCH with "
          f"jtag_sim_checker, which reports which tensor differs.")


if __name__ == "__main__":
    main()
